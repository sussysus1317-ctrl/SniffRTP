# SniffRTP recovered source

This package contains source recovered from all nine supplied SniffRTP JARs.
It preserves each platform separately because a JAR does not contain the
original multi-module Gradle layout.

## Included platforms

| Directory | Supplied build |
| --- | --- |
| `platforms/bukkit` | Bukkit 26.2 |
| `platforms/fabric` | Fabric Server 26.2 |
| `platforms/folia` | Folia 26.2 |
| `platforms/forge` | Forge Server 26.2 |
| `platforms/neoforge` | NeoForge Server 26.2 |
| `platforms/paper` | Paper 26.2 |
| `platforms/purpur` | Purpur 26.2 |
| `platforms/spigot` | Spigot 26.2 |
| `platforms/sponge` | Sponge Server 1.21.11 |

There are 119 recovered `.java` files across the nine platform trees. The
same common classes appear in multiple trees because the deliverable preserves
what was in each binary. Only classes under `dev.deepslate.sniffrtp` were
decompiled. The approximately 770 `net.kyori` classes in every original JAR
are a shaded third-party Adventure dependency, not SniffRTP source.

## Build the deliverables

Python 3 is the only requirement:

```sh
python3 tools/build.py
```

The command creates:

- one source ZIP for each platform;
- one combined source ZIP suitable for source disclosure/review;
- one deterministic reassembled JAR for each platform; and
- a verification report proving every reassembled JAR entry has the same
  uncompressed bytes as its supplied binary input.

Outputs are written under `dist/`. You can also run:

```sh
python3 tools/build.py --verify-only
```

## Important recovery limitation

Decompilation recovers equivalent Java structure, but it cannot recover the
original comments, local variable names, formatting, Gradle scripts, mappings,
or dependency lockfiles. The verified JAR build therefore reassembles the
supplied bytecode and resources; it does **not** claim that the recovered Java
was cleanly recompiled. Exact source recompilation needs the original build
configuration or newly reconstructed loader-specific dependency definitions.

The recovered Java is still useful for source disclosure and for rebuilding a
maintainable repository. Review CFR's occasional `WARNING` comments before
editing complex methods. See `analysis/DECOMPILATION.md` for the obfuscation
and integrity-check findings.

## Attribution

The embedded attribution identifies `imsoback` / `sussysus1317-ctrl` and asks
that the credit not be removed. That credit, the embedded configuration license
header, and the integrity resources have been preserved.
