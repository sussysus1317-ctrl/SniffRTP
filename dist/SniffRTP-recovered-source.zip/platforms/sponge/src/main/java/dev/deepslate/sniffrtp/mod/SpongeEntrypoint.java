/*
 * Decompiled with CFR 0.152.
 */
package dev.deepslate.sniffrtp.mod;

import dev.deepslate.sniffrtp.mod.VanillaRtp;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import javax.inject.Inject;
import net.kyori.adventure.text.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.LivingEntity;
import org.spongepowered.api.Server;
import org.spongepowered.api.command.Command;
import org.spongepowered.api.command.CommandCause;
import org.spongepowered.api.command.CommandCompletion;
import org.spongepowered.api.command.CommandResult;
import org.spongepowered.api.command.parameter.ArgumentReader;
import org.spongepowered.api.entity.Entity;
import org.spongepowered.api.entity.living.Living;
import org.spongepowered.api.entity.living.player.server.ServerPlayer;
import org.spongepowered.api.event.Cancellable;
import org.spongepowered.api.event.Listener;
import org.spongepowered.api.event.Order;
import org.spongepowered.api.event.block.InteractBlockEvent;
import org.spongepowered.api.event.entity.DamageEntityEvent;
import org.spongepowered.api.event.entity.DestructEntityEvent;
import org.spongepowered.api.event.entity.InteractEntityEvent;
import org.spongepowered.api.event.entity.MoveEntityEvent;
import org.spongepowered.api.event.lifecycle.RegisterCommandEvent;
import org.spongepowered.api.event.lifecycle.StartedEngineEvent;
import org.spongepowered.api.event.lifecycle.StoppingEngineEvent;
import org.spongepowered.api.scheduler.ScheduledTask;
import org.spongepowered.api.scheduler.Task;
import org.spongepowered.api.util.Ticks;
import org.spongepowered.api.util.Tristate;
import org.spongepowered.plugin.PluginContainer;
import org.spongepowered.plugin.builtin.jvm.Plugin;

@Plugin(value="sniffrtp")
public final class SpongeEntrypoint {
    private final PluginContainer plugin;
    private VanillaRtp rtp;
    private ScheduledTask clock;
    private final Map<UUID, net.minecraft.server.level.ServerPlayer> players = new HashMap<UUID, net.minecraft.server.level.ServerPlayer>();

    @Inject
    public SpongeEntrypoint(PluginContainer plugin) {
        this.plugin = plugin;
    }

    private void initialize() {
        if (this.rtp != null) {
            return;
        }
        this.rtp = new VanillaRtp();
        this.rtp.platformPermission = (p, node) -> {
            Tristate value = ((ServerPlayer)p).permissionValue(node);
            return value == Tristate.UNDEFINED ? null : Boolean.valueOf(value == Tristate.TRUE);
        };
    }

    @Listener
    public void commands(RegisterCommandEvent<Command.Raw> event) throws Exception {
        this.initialize();
        event.register(this.plugin, (Object)new Raw(false), "rtp", new String[0]);
        event.register(this.plugin, (Object)new Raw(true), "sniffrtp", new String[0]);
    }

    @Listener
    public void started(StartedEngineEvent<Server> event) {
        this.initialize();
        this.clock = ((Server)event.engine()).scheduler().submit(Task.builder().plugin(this.plugin).interval(Ticks.of((long)1L)).execute(() -> {
            this.rtp.tick((MinecraftServer)event.engine());
            this.players.values().removeIf(p -> {
                if (this.rtp.online((net.minecraft.server.level.ServerPlayer)p)) {
                    return false;
                }
                this.rtp.quit((net.minecraft.server.level.ServerPlayer)p);
                return true;
            });
        }).build());
    }

    @Listener
    public void stopped(StoppingEngineEvent<Server> event) {
        if (this.clock != null) {
            this.clock.cancel();
        }
        if (this.rtp != null) {
            this.rtp.stop();
        }
        this.players.clear();
    }

    @Listener(order=Order.POST)
    public void moved(MoveEntityEvent event) {
        Entity entity;
        if (this.rtp != null && !event.isCancelled() && (entity = event.entity()) instanceof ServerPlayer) {
            ServerPlayer p = (ServerPlayer)entity;
            if (event.originalPosition().distanceSquared(event.destinationPosition()) > 1.0E-4) {
                this.rtp.moved((net.minecraft.server.level.ServerPlayer)p);
            }
        }
    }

    @Listener(order=Order.POST)
    public void death(DestructEntityEvent.Death event) {
        Living living;
        if (this.rtp != null && !event.isCancelled() && (living = event.entity()) instanceof ServerPlayer) {
            ServerPlayer p = (ServerPlayer)living;
            this.rtp.engine.cancel((net.minecraft.server.level.ServerPlayer)p, "died", false, false);
        }
    }

    @Listener(order=Order.POST)
    public void damage(DamageEntityEvent event) {
        if (this.rtp == null || event.isCancelled() || event.baseDamage() <= 0.0) {
            return;
        }
        event.cause().first(org.spongepowered.api.event.cause.entity.damage.source.DamageSource.class).ifPresent(source -> {
            Entity e = event.entity();
            org.spongepowered.api.event.cause.entity.damage.source.DamageSource s = source;
            if (e instanceof LivingEntity) {
                LivingEntity victim = (LivingEntity)e;
                if (s instanceof DamageSource) {
                    DamageSource damage = (DamageSource)s;
                    this.rtp.damage(victim, damage);
                }
            }
        });
    }

    @Listener(order=Order.POST)
    public void block(InteractBlockEvent event) {
        Cancellable c;
        if (!(this.rtp == null || event instanceof Cancellable && (c = (Cancellable)event).isCancelled())) {
            event.cause().first(ServerPlayer.class).ifPresent(p -> this.rtp.interact((net.minecraft.server.level.ServerPlayer)p));
        }
    }

    @Listener(order=Order.POST)
    public void entity(InteractEntityEvent event) {
        InteractEntityEvent c;
        if (!(this.rtp == null || event instanceof Cancellable && (c = event).isCancelled())) {
            event.cause().first(ServerPlayer.class).ifPresent(p -> this.rtp.interact((net.minecraft.server.level.ServerPlayer)p));
        }
    }

    private final class Raw
    implements Command.Raw {
        final boolean recovery;

        Raw(boolean recovery) {
            this.recovery = recovery;
        }

        public CommandResult process(CommandCause cause, ArgumentReader.Mutable args) {
            String target = args.remaining().trim();
            Optional player = cause.first(ServerPlayer.class);
            if (this.recovery) {
                if (!cause.hasPermission("rtp.admin")) {
                    cause.sendMessage((Component)Component.text((String)"Missing rtp.admin permission."));
                    return CommandResult.builder().result(0).build();
                }
                if (target.equalsIgnoreCase("yes") || target.equalsIgnoreCase("nah")) {
                    SpongeEntrypoint.this.rtp.config.restore(target.equalsIgnoreCase("yes"));
                    return CommandResult.success();
                }
                cause.sendMessage((Component)Component.text((String)"Use /sniffrtp yes or /sniffrtp nah."));
                return CommandResult.builder().result(0).build();
            }
            if (player.isEmpty()) {
                if (target.equalsIgnoreCase("reload") && cause.hasPermission("rtp.admin")) {
                    SpongeEntrypoint.this.rtp.config.reload();
                    return CommandResult.success();
                }
                cause.sendMessage((Component)Component.text((String)"Only players can use /rtp."));
                return CommandResult.builder().result(0).build();
            }
            net.minecraft.server.level.ServerPlayer p = (net.minecraft.server.level.ServerPlayer)player.get();
            SpongeEntrypoint.this.players.put(p.getUUID(), p);
            int result = SpongeEntrypoint.this.rtp.command(p.createCommandSourceStack(), target);
            return result > 0 ? CommandResult.success() : CommandResult.builder().result(0).build();
        }

        public List<CommandCompletion> complete(CommandCause cause, ArgumentReader.Mutable args) {
            String input = args.remaining().toLowerCase(Locale.ROOT);
            return (this.recovery ? List.of("yes", "nah") : List.of("overworld", "nether", "end", "custom", "cancel", "reload")).stream().filter(s -> s.startsWith(input)).map(CommandCompletion::of).toList();
        }

        public boolean canExecute(CommandCause cause) {
            return !this.recovery || cause.hasPermission("rtp.admin");
        }

        public Optional<Component> shortDescription(CommandCause cause) {
            return Optional.of(Component.text((String)(this.recovery ? "Restore SniffRTP configuration" : "Random teleport")));
        }

        public Optional<Component> extendedDescription(CommandCause cause) {
            return this.shortDescription(cause);
        }

        public Component usage(CommandCause cause) {
            return Component.text((String)(this.recovery ? "yes|nah" : "[world|biome|cancel|reload]"));
        }
    }
}

